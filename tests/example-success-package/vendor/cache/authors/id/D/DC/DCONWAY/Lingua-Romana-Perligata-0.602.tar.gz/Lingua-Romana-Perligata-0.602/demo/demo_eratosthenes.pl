use Lingua::Romana::Perligata;

                      maximum tum val inquementum
                tum biguttam tum stadium egresso scribe.
                             meo maximo
                        vestibulo perlegementum
                             da.

            maximum comementum tum novumversum egresso scribe.
                              da meis listis
                   conscribementa II tum maximum.
                       dum damentum nexto listis
                           decapitamentum fac

               sic lista sic hoc tum nextum recidementum
                       cis vannementa listis da.
                 dictum sic deinde cis tum biguttam tum
                         stadium tum cum nextum
               comementum tum novumversum scribe egresso.
                                  cis

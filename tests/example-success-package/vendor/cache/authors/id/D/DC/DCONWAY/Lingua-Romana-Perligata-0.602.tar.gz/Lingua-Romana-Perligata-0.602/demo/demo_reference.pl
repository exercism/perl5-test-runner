use Lingua::Romana::Perligata
  'converte',
# 'discribe'
# 'investiga',
;

valo da arcessementum varum.
valo da arcessementa varum.
valo da arcessementus varum.

valo da varumementum valum.
valis da varumementa valum.
varumemento valum da valum.
varume valum.

valum da arcessemento varum.
valum da arcessementis varum.
valum da arcessementibus varum.

scribe egresso arcessementa arcessementum arcessementum arcessementum varum.
scribe egresso secundum varum arcessementorum.
scribe egresso secundum varum arcessementuum.
scribe egresso secundum varum arcessementi hashuum.
scribe egresso secundum varum arcessementi arrorum.
scribe egresso secundum varum intra Class arcessementi arrorum intra Class2.

funcemento da ad inquemento val datuum.
ad val inquemento datuum dato da.       
ad inquemento val datuum argis da.        
ad val inquemento datuum intra Class dato intra Class da.       

val inquemento datuum ad dato da.       
arg inquemento datuum ad argis da.        
act inquemento datuum functorem da.      

dato factorem sic oops inquementum mori cis da.      
act inquemento datuum factorem sic oops inquementum mori cis da.      
factori sic primo nullimi horum postincresce cis MyClass inquementum benedictum da objo.

objo da benedictum functori classum.             
objo da benedictum factori sic mori messagum cis classum.  


use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

    domus Exemplar intra Simplicio.

        printere
        sic
            meo selfo his decapitamentum da.
            haec inquementum carpe.
        cis

    domus Specimen.
    legatarius Exemplar intra Simplicio.

    meis datis.

        newere
        sic
            meis datibus.
        counto intra Specimen postincresce.
        preincrescemento no intra Max datorum
        intra Specimen intra Max da I.
            redde datibus nullimum horum benedictum.
        cis

        domus princeps.

        meo objecto da newementum apud Specimen.

        I tum III printe apud objectum.
        I printe apud objectum.
    dictum sic et cetera cis printe apud Specimen.

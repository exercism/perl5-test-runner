use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

sic maximum value: cis dictum tum stadium egresso scribe.
vestibulo perlegementum da meo maximo .
maximum tum novumversum egresso scribe.
da II tum maximum conscribementa meis listis.
dum damentum nexto listis decapitamentum fac sic
       lista sic hoc tum nextum recidementum  cis vannementa da listis.
       next tum biguttam tum stadium tum nextum tum novumversum scribe egresso.
    cis

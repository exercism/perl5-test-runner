use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;


listis I tum X conscribementa da.

sic hoc tum V praestantiam cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic V tum hoc praestantiam cis lista vannementa egresso scribe.
novumversum egresso scribe.
vannementa sic hoc tum V non praestantiam cis lista egresso scribe.
novumversum egresso scribe.
vannementa sic V tum hoc non praestantiam cis lista egresso scribe.
novumversum egresso scribe.

sic hoc tum V comparitiam cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic V tum hoc comparitiam cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic hoc tum V comparitiam non cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic hoc tum V non comparitiam cis lista vannementa egresso scribe.
novumversum egresso scribe.


listis a tum z conscribementa da.
Vo da v inquementum.

sic hoc tum Vum praestantias cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic Vum tum hoc praestantias cis lista vannementa egresso scribe.
novumversum egresso scribe.
vannementa sic hoc tum Vum non praestantias cis lista egresso scribe.
novumversum egresso scribe.
vannementa sic Vum tum hoc non praestantias cis lista egresso scribe.
novumversum egresso scribe.

sic hoc tum Vum comparitias cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic Vum tum hoc comparitias cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic hoc tum Vum comparitias non cis lista vannementa egresso scribe.
novumversum egresso scribe.
sic hoc tum Vum non comparitias cis lista vannementa egresso scribe.
novumversum egresso scribe.

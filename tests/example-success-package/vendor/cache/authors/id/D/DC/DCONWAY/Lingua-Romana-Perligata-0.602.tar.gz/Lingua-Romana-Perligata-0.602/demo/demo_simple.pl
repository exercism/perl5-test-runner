use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

ute Tabs sicut intra Text.

inscribe label.
dum nexto preincrescementum tum XCIX praestantiam fac sic
    si nextum tum duo recidementum fac sic posterus cis.
    nextum tum addementum nextum tum unum oute.
    egresso scribe biguttam tum XI iteramentum tum novumversum.
cis

outere sic
    scribe egresso haec admetamentum tum novumversum.
    sic
    scribe egresso next tum is inquementum tum biguttam
                    tum lacunam tum hoc tum novumversum.
    cis per quisque hoc in his fac.
cis

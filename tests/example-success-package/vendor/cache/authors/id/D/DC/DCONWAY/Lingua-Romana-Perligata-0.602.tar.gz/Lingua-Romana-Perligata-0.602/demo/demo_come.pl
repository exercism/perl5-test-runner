use Lingua::Romana::Perligata
# 'converte',
# 'discribe'
# 'investiga',
;

per quisque in I tum (((((I)))))I))))CDVII conscribemento fac
    sic
        hoc tum duo multiplicamentum comementum tum novumversum egresso scribe.
    cis.

use Lingua::Romana::Perligata;

per quisque clavum in I tum III conscribemento fac
    sic
        dictum sic Numerum cis tum biguttam tum lacunam egresso scribe.
        da meo numero vestibulo perlegementum.

        meis listis II tum cum numerum fodementum conscribementa da.

        dum damentum nexto listis decapitamentum fac
            sic
                lista sic hoc tum nextum recidementum cis vannementa da listis.
                si numerum tum nextum recidementum tum nullum aequalitam fac sic
                    dictum sic Non primus: cis tum lacunam egresso scribe.
                    numerum tum nextum dividementum comementum egresso scribe.
                    lacunam tum dictum sic x cis tum lacunam
                            tum cum nextum comementum tum novumversum egresso scribe.
                    nullum exi.
                cis
            cis.

        egresso scribe dictum sic Primus cis tum novumversum.
    cis

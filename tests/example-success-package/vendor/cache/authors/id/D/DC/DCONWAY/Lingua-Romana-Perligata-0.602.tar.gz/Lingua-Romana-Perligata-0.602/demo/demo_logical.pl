use Lingua::Romana::Perligata
  'converte',
# 'discribe'
# 'investiga',
;

    reso da foundum atque defementum valum.
    reso damentum foundum defementumque valum.
    reso da foundum vel defementum valum.
    reso damentum foundum defementumve valum.

    reso da foundum atque runementum.
        reso damentum foundum runementumque.
        reso da foundum vel runementum.
        reso damentum foundum runementumve.

    resulto damentum valum parprimumque tum parsecundum maxementum.
    resulto damentum valum maxementumque parprimum tum parsecundum.
